## ------------------------------------------------------
##        Name: Helen Danielson and Kate Spencer
##    Filename: final.py
##     Section: L03/ L04
##        Date: 4/28/19
##  References: https://realpython.com/lessons/advanced-csv-reader-parameters/
##              https://docs.python.org/3/library/csv.html#csv.DictReader
## ------------------------------------------------------

## WELCOME TO SI Sizing (Standard Intelligent Sizing)
import csv
from store import *
import datetime
from ui import *

def getInput(hnm,asos,zara,oldnavy):
    ''' get input takes in a multiple store class object, and prints the users sizes based on
    their inputed measurements and their store selection. No longer used after
    implementing graphics.py'''
    #takes in the three measurements used to determine size 
    inchest = eval(input("Enter your chest size in inches: "))
    inwaist = eval(input("Enter your waist size in inches: "))
    inhip = eval(input("Enter your hip size in inches: "))

    #lets the user choose which store(s) they want their size for, and prints it
    ynhnm = input("Do you want your sizes for H&M? ")
    if ynhnm.upper() == "YES":
        hnm.printSizes(inchest,inwaist,inhip)
    ynasos = input("Do you want your size for ASOS? ")
    if ynasos.upper() == "YES":
        print(asos.returnSizes(inchest,inwaist,inhip))
    ynzara = input("Do you want your size for Zara? ")
    if ynzara.upper() == "YES":
        zara.printSizes(inchest,inwaist,inhip)
    ynoldnavy = input("Do you want your size for OldNavy? ")
    if ynoldnavy.upper() == "YES":
        oldnavy.printSizes(inwaist,inhip)

    ynsave = input("Do you want to save your sizes? ")
    if ynsave.upper() == "YES":
        saveAs(inchest, inwaist, inhip, hnm, asos, zara, oldnavy)
    
def saveAs(chest, waist, hip, hnm, asos, zara, oldnavy,note):
    '''takes in users sizes, stores, and a note/label for the sizes and adds the
    users sizes in each store to a .txt file called yourSizes.txt.'''
    file = open("yourSizes.txt", "a+")
    now = datetime.datetime.now()
    file.write("\n\n"+note +" "+ str(now)+" ")
    file.write("\nHere are your sizes for H&M:")
    file.write("\n\tYour top size is: " + hnm.tops(chest))
    file.write("\n\tYour dress size is: "+ hnm.dresses(chest))
    file.write("\n\tYour bottoms size is: "+ hnm.bottoms(waist, hip))
    file.write("\n\tYour jeans size is: "+ hnm.jeans(waist))
    file.write("\nYour ASOS size is :"+ asos.getSize(chest, waist, hip))
    file.write("\nYour Zara size is :"+ zara.getSize(chest, waist, hip))
    file.write("\nYour OldNavy size is :"+ oldnavy.getSize(waist, hip))
    file.close()
    
def instantiate():
    #open and creates reader for each store, then instantiates each store as an object
    with open("hnm.csv") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter = ",")
        hnm = HnM(csv_reader)
    with open("asos.csv") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter = ",")
        asos = ASOS(csv_reader)
    with open("zara.csv") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter = ",")
        zara = Zara(csv_reader)
    with open("oldnavy.csv") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter = ",")
        oldnavy = OldNavy(csv_reader)

    #calls the Home function from ui.py, opening a home screen for SI sizing
    Home(hnm,asos,zara,oldnavy)

def main():
    #instantiates the Store objects from store.py
    instantiate()        

if __name__ == "__main__":
    main()




