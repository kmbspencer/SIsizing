## ------------------------------------------------------
##        Name: Helen Danielson and Kate Spencer
##    Filename: store.py
##     Section: L03/ L04
##        Date: 4/26/19
##  References: https://www2.hm.com/en_us/customer-service/sizeguide/ladies.html
##              https://www.asos.com/infopages/SizeGuide/pgesizechart.aspx
##              http://www.zara.com/webapp/wcs/stores/servlet/ProductGuideSizeAjaxView?langId=-1&productId=1794608&storeId=11719
##              https://oldnavy.gap.com/products/size-chart.jsp#Wtops
## ------------------------------------------------------
import csv 

class Store:
    ''' A base class that all other stores extend, all stores should have
    methods that decide on sizes based on an inputed CSV file'''
    def getChestMeasurement(self, topsize):
        self.topsize = topsize
        for key,value in self.chest.items():
            if self.topsize == value:
                return key
    def getWaistMeasurement(self, bottomssize):
        self.bottomssize = bottomssize
        for key,value in self.waist.items():
            if self.bottomssize == value:
                return key
    def getHipMeasurement(self, bottomssize):
        self.bottomssize = bottomssize
        for key,value in self.hip.items():
            if self.bottomssize == value:
                return key
class HnM(Store):
    ''' HnM extends Store and is a class for the store H & M. Takes in a csv reader with the size chart,
    and can also take user's waist, chest, and low hip measurements and returns
    their size at H&M'''

    def __init__(self, hnmreader):
        self.hnmreader = hnmreader
        self.row_num =0
    #creates empty dictionaries for chest, waist, jeans waist, and hip measurements
        self.chest = {}
        self.waist = {}
        self.jwaist = {}
        self.hip = {}
    #fills the dictionarys with measurements (in inches) as the key, and the
    #corresponding size as the value
        for row in self.hnmreader:
    #removes first column (this is the label of which sizes are in the row)
            row.pop(0)
    #creates a list of all avalible sizes
            if self.row_num ==0:
                self.sizelist= row
    #fills the chest dictionary with measurements as keys and sizes as values
            if self.row_num ==1:
                self.count = 0
                for size in row:
                    self.chest[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the waist dictionary with measurements as keys and sizes as values
            if self.row_num ==2:
                self.count = 0
                for size in row:
                    self.waist[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the jwaist(jeans waist)dictionary with measurements as keys and sizes as values
            if self.row_num ==3:
                self.count = 0
                for size in row:
                    self.jwaist[int(size)] = self.sizelist[self.count]
                    self.count +=1
    #removes sizes 20-30 from the jeans dictionary, as jeans stop at size 18
                self.jwaist.pop(1)
                self.jwaist.pop(2)
                self.jwaist.pop(3)
                self.jwaist.pop(4)
                self.jwaist.pop(5)
                self.jwaist.pop(6)
    #fills the low hip dictionary with measurements as keys and sizes as values
            if self.row_num ==4:
                self.count = 0
                for size in row:
                    self.hip[float(size)] = self.sizelist[self.count]
                    self.count +=1
            self.row_num += 1
            
    #creates lists for the different measurements of just the measurements(in inches)
        self.chest_sizes = list(self.chest.keys())
        self.waist_sizes = list(self.waist.keys())
        self.jwaist_sizes = list(self.jwaist.keys())
        self.hip_sizes = list(self.hip.keys())

        
    def tops(self, chest_measure):
        ''' takes in an inputed chest measurement(int) and returns the correct size of top(string)
        for the user'''
        self.chest_measure = chest_measure
    #if the chest measurement is  or is smaller than size 0 they are size 0
        if self.chest_measure <= 30:
            return("0")
    #if the chest measurement larger than size 30 they are size 30
        if self.chest_measure > 59.75:
            return("30")
    #else returns the size that the chest measurement is smaller than,
    #but bigger than the size before it (size1<chest_measure<= size2 return size2)
        else:
            for i in range(len(self.chest_sizes)):
                if self.chest_measure > self.chest_sizes[i-1] and self.chest_measure <= self.chest_sizes[i]:
                    return self.chest[self.chest_sizes[i]]

    def bottoms(self, waist_measure, hip_measure):
        ''' takes a users waist measure(int) and low hip measure(int) and returns
        a pants/bottoms size(string) based on those measures'''

        self.waist_size = "0"
        self.hip_size = "0"
    #finds the size based on the waist measurement using same logic as tops
        self.waist_measure = waist_measure
        if self.waist_measure <= 23.75:
            self.waist_size = "0"
        if self.waist_measure > 53.5:
            self.waist_size = "30"
        else:
            for i in range(len(self.waist_sizes)):
                if self.waist_measure > self.waist_sizes[i-1] and self.waist_measure <= self.waist_sizes[i]:
                    self.waist_size = self.waist[self.waist_sizes[i]]
    #finds a users size based on the users hip measurement using same logic as tops
        self.hip_measure = hip_measure
        if self.hip_measure <= 33:
            self.hip_size = "0"
        if self.hip_measure > 59.75:
            self.hip_size = "30"
        else:
            for i in range(len(self.hip_sizes)):
                if self.hip_measure > self.hip_sizes[i-1] and self.hip_measure <= self.hip_sizes[i]:
                    self.hip_size = self.hip[self.hip_sizes[i]]
                    
    #compares the size at the hip and the size at the waist and returns the larger size
        if self.waist_size > self.hip_size:
            return self.waist_size
        if self.waist_size <= self.hip_size:
            return self.hip_size
        

    def dresses(self, chest_measure):
        ''' takes in a users chest_measurement(int) and returns their dress size(string)'''
    #dress and top size are the same, so call and return top size
        return(self.tops(chest_measure))

    def jeans(self, jwaist_measure):
        ''' takes in a users waist measurement(int) and retuns a jeans size
        - note waist and jwaist have the measurements and sizes, the only difference
        is that jeans stop at size 18'''
    #finds and returns a users size based on waist measurement using the same logic as top
        self.jwaist_measure = jwaist_measure
        if self.jwaist_measure <= 24:
            return("0")
        if self.jwaist_measure > 38:
            return("18")
        else:
            for i in range(len(self.jwaist_sizes)):
                if self.jwaist_measure > self.jwaist_sizes[i-1] and self.jwaist_measure <= self.jwaist_sizes[i]:
                    return self.jwaist[self.jwaist_sizes[i]]

    def printSizes(self, chest, waist, hip):
        ''' takes in a users chest, waist, and hip measurements (ints) and prints out their top, dress,
        bottom, and jeans sizes(string)'''
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        self.injwaist = self.inwaist
        #calls the functions used to dertermine sizes at H&M, and prints the result
        print("Here are your sizes for H&M:")
        print("Your top size is: ", self.tops(self.inchest))
        print("Your dress size is: ", self.dresses(self.inchest))
        print("Your bottoms size is: ", self.bottoms(self.inwaist, self.inhip))
        print("Your jeans size is: ", self.jeans(self.injwaist))

    def returnSizes(self, chest, waist, hip):
        ''' takes in a users chest, waist, and hip measurements (ints) and prints out their top, dress,
        bottom, and jeans sizes(string)'''
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        self.injwaist = self.inwaist
        return "Your sizes at H&M:"+"\nYour top size is: "+ self.tops(self.inchest)+"\nYour dress size is: "+ self.dresses(self.inchest)+"\nYour bottoms size is: "+ self.bottoms(self.inwaist, self.inhip)+"\nYour jeans size is: "+ self.jeans(self.injwaist)
        
    def getJWaistMeasurement(self, jeanssize):
        self.jeanssize = jeanssize
        for key,value in self.jwaist.items():
            if self.jeanssize == value:
                return key

    def Note(self):
        '''Note prints any important information about H&M, as well as the link to the online size chart'''
        print("This program is basing sizing on US Sizes")
        print("H&M sizes go from 0-30 for tops, bottoms and dresses and 0-18 for jeans")
        print("Visit https://www2.hm.com/en_us/customer-service/sizeguide/ladies.html for the full size chart")

    def __str__(self):
        return "H&M"

class ASOS(Store):
    ''' ASOS extends Store and is a class for the store ASOS. Takes in a csv reader with the size chart,
    and can also take user's waist, chest, and hip measurements and returns
    their size at ASOS'''

    def __init__(self, asosreader):
        self.asosreader = asosreader
        self.row_num =0

    #creates empty dictionaries for chest, waist, and hip measurements"
        self.chest = {}
        self.waist = {}
        self.hip = {}
    #fills the dictionarys with measurements (in inches) as the key, and the
    #corresponding size as the value
        for row in self.asosreader:
    #removes first column (this is the label of which sizes are in the row)
            row.pop(0)
    #creates a list of all avalible sizes
            if self.row_num ==0:
                self.sizelist= row
    #fills the chest dictionary with measurements as keys and sizes as values
            if self.row_num ==1:
                self.count = 0
                for size in row:
                    self.chest[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the waist dictionary with measurements as keys and sizes as values
            if self.row_num ==2:
                self.count = 0
                for size in row:
                    self.waist[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the hip dictionary with measurements as keys and sizes as values
            if self.row_num ==3:
                self.count = 0
                for size in row:
                    self.hip[float(size)] = self.sizelist[self.count]
                    self.count +=1
            self.row_num += 1
            
    #creates lists for the different measurements of just the measurements(in inches)
        self.chest_sizes = list(self.chest.keys())
        self.waist_sizes = list(self.waist.keys())
        self.hip_sizes = list(self.hip.keys())
        
    def getSize(self, chest_measure, waist_measure, hip_measure):
        '''getSize takes in the users chest, waist, and hip measurements(ints)
        and returns their size at ASOS (string)'''
        self.chest_measure = chest_measure
        self.waist_measure = waist_measure
        self.hip_measure = hip_measure
    #if the chest measurement is  or is smaller than the smallest size return smallest size
        if self.chest_measure <= 30:
            self.chest_size =("1")
    #if the chest measurement larger than largest size return largest size
        if self.chest_measure > 53:
            self.chest_size =("22")
    #else returns the size that the chest measurement is smaller than,
    #but bigger than the size before it (size1<chest_measure<= size2 return size2)
        else:
            for i in range(len(self.chest_sizes)):
                if self.chest_measure > self.chest_sizes[i-1] and self.chest_measure <= self.chest_sizes[i]:
                    self.chest_size = self.chest[self.chest_sizes[i]]

    #finds the size based on the waist measurement using same logic as tops
        self.waist_measure = waist_measure
        if self.waist_measure <= 22.75:
            self.waist_size = "1"
        if self.waist_measure > 46:
            self.waist_size = "22"
        else:
            for i in range(len(self.waist_sizes)):
                if self.waist_measure > self.waist_sizes[i-1] and self.waist_measure <= self.waist_sizes[i]:
                    self.waist_size = self.waist[self.waist_sizes[i]]

    #finds a users size based on their hip measurement using same logic as top
        self.hip_measure = hip_measure
        if self.hip_measure <= 32.75:
            self.hip_size = "1"
        if self.hip_measure > 56:
            self.hip_size = "22"
        else:
            for i in range(len(self.hip_sizes)):
                if self.hip_measure > self.hip_sizes[i-1] and self.hip_measure <= self.hip_sizes[i]:
                    self.hip_size = self.hip[self.hip_sizes[i]]
                    
    #compares the size at the hip and the size at the waist and returns the larger size
        list_sizes = [self.chest_size, self.waist_size, self.hip_size]
        return max(list_sizes)
    
    def printSizes(self, chest, waist, hip):
        ''' takes in the chest, waist, hip measurements(ints) and prints the users size at ASOS'''
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        print("Your ASOS size is :", self.getSize(self.inchest, self.inwaist, self.inhip))
    def returnSizes(self, chest, waist, hip):
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        return "Your ASOS size is : "+ self.getSize(self.inchest, self.inwaist, self.inhip)
        
    def Note(self):
        '''Note prints any important information about ASOS, as well as the link to the online size chart'''
        print("This program is basing sizing on US Sizes")
        print("ASOS sizes go from 1-22")
        print("For the full size chart visit https://www.asos.com/infopages/SizeGuide/pgesizechart.aspx")

    def __str__(self):
        return "ASOS"
    
class Zara(Store):
    ''' Zara extends Store and is a class for the store Zara. Takes in a csv reader with the size chart,
    and can also take user's waist, chest, and low hip measurements and returns
    their size at Zara'''
    def __init__(self, csv_reader):
        self.zarareader = csv_reader
        self.row_num =0

    #creates empty dictionaries for chest, waist, and hip measurements"
        self.chest = {}
        self.waist = {}
        self.hip = {}
    #fills the dictionarys with measurements (in inches) as the key, and the
    #corresponding size as the value
        for row in self.zarareader:
    #removes first column (this is the label of which sizes are in the row)
            row.pop(0)
    #creates a list of all avalible sizes
            if self.row_num ==0:
                self.sizelist= row
    #fills the chest dictionary with measurements as keys and sizes as values
            if self.row_num ==1:
                self.count = 0
                for size in row:
                    self.chest[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the waist dictionary with measurements as keys and sizes as values
            if self.row_num ==2:
                self.count = 0
                for size in row:
                    self.waist[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the hip dictionary with measurements as keys and sizes as values
            if self.row_num ==3:
                self.count = 0
                for size in row:
                    self.hip[float(size)] = self.sizelist[self.count]
                    self.count +=1
    
            self.row_num += 1
    #creates lists for the different measurements of just the measurements(in inches)
        self.chest_sizes = list(self.chest.keys())
        self.waist_sizes = list(self.waist.keys())
        self.hip_sizes = list(self.hip.keys())

    def getSize(self, chest, waist, hip):
        ''' takes in a users chest, waist, and hip size (int) and returns their size at Zara(string)'''
        self.chest_measure = chest
        self.waist_measure = waist
        self.hip_measure = hip
    #if the chest measurement is  or is smaller than size XXS they are size XXS
        if self.chest_measure <= 31.5:
            self.chest_size =("XXS")
    #if the chest measurement larger than size XXL they are size XXL
        if self.chest_measure > 42.5:
            self.chest_size =("XXL")
    #else returns the size that the chest measurement is smaller than,
    #but bigger than the size before it (size1<chest_measure<= size2 return size2)
        else:
            for i in range(len(self.chest_sizes)):
                if self.chest_measure > self.chest_sizes[i-1] and self.chest_measure <= self.chest_sizes[i]:
                    self.chest_size = self.chest[self.chest_sizes[i]]
        
    #finds the size based on the waist measurement using same logic as tops
        if self.waist_measure <= 22.8:
            self.waist_size = "XXS"
        if self.waist_measure > 34.6:
            self.waist_size = "XXL"
        else:
            for i in range(len(self.waist_sizes)):
                if self.waist_measure > self.waist_sizes[i-1] and self.waist_measure <= self.waist_sizes[i]:
                    self.waist_size = self.waist[self.waist_sizes[i]]
    #finds a users size based on their hip measurement using same logic as top
        if self.hip_measure <= 33.9:
            self.hip_size = "XXS"
        if self.hip_measure > 45.7:
            self.hip_size = "XXL"
        else:
            for i in range(len(self.hip_sizes)):
                if self.hip_measure > self.hip_sizes[i-1] and self.hip_measure <= self.hip_sizes[i]:
                    self.hip_size = self.hip[self.hip_sizes[i]]
                    
    #compares the size at the hip, chest, and waist and returns largest
    #becase sizes are letters not numbers, program finds the index of the sizes
    #in the size list and uses that to determine largest size
        self.chest_index = self.sizelist.index(self.chest_size)
        self.waist_index = self.sizelist.index(self.waist_size)
        self.hip_index = self.sizelist.index(self.hip_size)
        self.list_sizes = [self.chest_index, self.waist_index, self.hip_index]
        return(self.sizelist[max(self.list_sizes)])
        
    def printSizes(self, chest, waist, hip):
        '''takes in chest, waist, hip measurements(ints) and prints the users size at Zara'''
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        print("Your Zara size is :", self.getSize(self.inchest, self.inwaist, self.inhip))
     
    def returnSizes(self, chest, waist, hip):
        '''takes in chest, waist, hip measurements(ints) and prints the users size at Zara'''
        self.inchest = chest
        self.inwaist = waist
        self.inhip = hip
        return "Your Zara size is : "+ self.getSize(self.inchest, self.inwaist, self.inhip)
        
    def Note(self):
        '''Note prints any important information about Zara, as well as the link to the online size chart'''
        print("This program is basing sizing on US Sizes")
        print("Zara sizes go from XXS-XXL")
        print("For the full size chart visit http://www.zara.com/webapp/wcs/stores/servlet/ProductGuideSizeAjaxView?langId=-1&productId=1794608&storeId=11719")

    def __str__(self):
        return("Zara")
    
class OldNavy(Store):
    ''' OldNavy extends Store and is a class for the store OldNavy. Takes in a csv reader with the size chart,
    and can also take user's waist, and hip measurements and returns their size at OldNavy'''
    def __init__(self, csv_reader):
        self.navyreader = csv_reader
        self.row_num =0

    #creates empty dictionaries for waist, and hip measurements"
        self.waist = {}
        self.hip = {}
        
    #fills the dictionarys with measurements (in inches) as the key, and the
    #corresponding size as the value
        for row in self.navyreader:
    #removes first column (this is the label of which sizes are in the row)
            row.pop(0)
    #creates a list of all avalible sizes
            if self.row_num ==0:
                self.sizelist= row
            #csv file autochanges 00 to 0, so needs to be corrected
                self.sizelist[0]="00"
    #fills the waist dictionary with measurements as keys and sizes as values
            if self.row_num ==1:
                self.count = 0
                for size in row:
                    self.waist[float(size)] = self.sizelist[self.count]
                    self.count +=1
    #fills the hip dictionary with measurements as keys and sizes as values
            if self.row_num ==2:
                self.count = 0
                for size in row:
                    self.hip[float(size)] = self.sizelist[self.count]
                    self.count +=1
    
            self.row_num += 1
    #makes lists containing just the measurements for waist and hip
        self.waist_sizes = list(self.waist.keys())
        self.hip_sizes = list(self.hip.keys())

    def getSize(self, waist_measure, hip_measure):
        ''' takes in waist and hip measure(ints) and returns the users size at OldNavy(string)'''
        self.waist_measure = waist_measure
        self.hip_measure = hip_measure

        #finds the size based on the waist measurement
        if self.waist_measure <= 23:
            self.waist_size = "00"
        if self.waist_measure > 39.5:
            self.waist_size = "20"
        else:
            for i in range(len(self.waist_sizes)):
                if self.waist_measure > self.waist_sizes[i-1] and self.waist_measure <= self.waist_sizes[i]:
                    self.waist_size = self.waist[self.waist_sizes[i]]
        #finds a users size based on their hip measurement
        if self.hip_measure <= 34:
            self.hip_size = "00"
        if self.hip_measure > 50.5:
            self.hip_size = "20"
        else:
            for i in range(len(self.hip_sizes)):
                if self.hip_measure > self.hip_sizes[i-1] and self.hip_measure <= self.hip_sizes[i]:
                    self.hip_size = self.hip[self.hip_sizes[i]]
                    
    #compares the size at the hip and the size at the waist and returns the larger size
        if self.waist_size > self.hip_size:
            return self.waist_size
        if self.waist_size <= self.hip_size:
            return self.hip_size

    def printSizes(self, waist, hip):
        '''takes in a users waist and hip size(ints) and prints their size at OldNavy'''
        self.inwaist = waist
        self.inhip = hip
        print("Your OldNavy size is :", self.getSize(self.inwaist, self.inhip))

    def returnSizes(self, waist, hip):
        '''takes in a users waist and hip size(ints) and prints their size at OldNavy'''
        self.inwaist = waist
        self.inhip = hip
        return "Your OldNavy size is : "+ self.getSize(self.inwaist, self.inhip)

    def Note(self):
        '''Note prints any important information about OldNavy, as well as the link to the online size chart'''
        print("This program is basing sizing on US Sizes")
        print("OldNavy sizes go from 00-20")
        print("For the full size chart visit https://oldnavy.gap.com/products/size-chart.jsp#Wtops")

    def __str__(self):
        return "OldNavy"
    
