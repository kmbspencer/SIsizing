## ------------------------------------------------------
##        Name: Helen Danielson Kate Spencer
##    Filename: ui.py
##     Section: L03/L04
##        Date: 4/28/19
##  References: graphics.py documentation
##              
## ------------------------------------------------------
from graphics import *
from store import *
from final import *

def Sizes(hnm,asos, zara, oldnavy,inchest, inwaist, inhip):
    ''' sizes creates a window and displays a users size on it, based on inputs and Stores passes in'''
    #creates a window and title message
    win = GraphWin("Sizes", 600, 500)
    win.setBackground("Alice Blue")
    message = Text(Point(300,40), "Your Sizes")
    message.setSize(30)
    message.setFace("courier") 
    message.draw(win)

    #displays a users size at h&m on the window
    handm = Text(Point(300, 130), hnm.returnSizes(inchest, inwaist, inhip))
    handm.setSize(15)
    handm.setFace("courier") 
    handm.draw(win)

    #displays a users size at asos on the window
    asosprint = Text(Point(300, 210), asos.returnSizes(inchest, inwaist, inhip))
    asosprint.setSize(15)
    asosprint.setFace("courier")
    asosprint.draw(win)

    #displays a users size at zara on the window
    zaraprint = Text(Point(300, 260), zara.returnSizes(inchest, inwaist, inhip))
    zaraprint.setSize(15)
    zaraprint.setFace("courier")
    zaraprint.draw(win)

    #displays a users size at old navy on the window
    oldnavyprint = Text(Point(300, 310), oldnavy.returnSizes(inwaist, inhip))
    oldnavyprint.setSize(15)
    oldnavyprint.setFace("courier")
    oldnavyprint.draw(win)

    #gives users the option to save and lable their sizes
    saveBox = Rectangle(Point(200,380), Point(400,400))
    saveBox.setFill("sky blue")
    saveBox.draw(win)

    savemessage = Text(Point(300,390), "Enter a label for your sizes:")
    note = Entry(Point(300,420), 50)
    savemessage.draw(win)
    note.draw(win)   

    goBox = Rectangle(Point(280,470), Point(320,490))
    goBox.setFill("sky blue")
    goBox.draw(win)

    goButton = Text(Point(300,480), "Save")
    goButton.draw(win)

    #checks to see if the user clicked the save button, if so saves their results
    #to yourSizes.txt, a txt file in the same folder as the program.
    choice=True
    while choice:
        clickPoint = win.getMouse()
        if 280<clickPoint.getX()<320 and 470<clickPoint.getY()<490: 
            saveAs(inchest, inwaist, inhip, hnm, asos, zara, oldnavy,note.getText())
            choice = False
            
def reverse(hnm,asos, zara, oldnavy):
    ''' takes in stores, and asks for users size in those stores, then uses their size to approxamate
    their size at other stores'''
    #creates a window with an instruction title
    rwin = GraphWin("Find Measurements", 600, 400)
    rwin.setBackground("Alice Blue")
    rmessage = Text(Point(300,40), "Enter your size in one of these stores:")
    rmessage.setSize(15)
    rmessage.setFace("courier") 
    rmessage.draw(rwin)

    #gives users the option to enter an ASOS size
    asosmessage = Text(Point(300,150), "ASOS:")
    asossize = Entry(Point(300,180), 5)
    asosmessage.draw(rwin)
    asosmessage.setSize(15)
    asosmessage.setFace("courier")
    asossize.draw(rwin)

    #gives users the option to enter an ZARA size
    zaramessage = Text(Point(300,220), "ZARA:")
    zarasize = Entry(Point(300,240), 5)
    zaramessage.draw(rwin)
    zaramessage.setSize(15)
    zaramessage.setFace("courier")
    zarasize.draw(rwin)

    #creates a button for a users to click when they have entered their size
    doneBox = Rectangle(Point(280,340), Point(320,360))
    doneBox.setFill("sky blue")
    doneBox.draw(rwin)

    nextmessage = Text(Point(300,350), "done")
    nextmessage.draw(rwin)

    #chesks which size the users entered, then uses the estimations based
    #on that size to find sizes at other stores
    choice = True
    while choice:
        clickPoint = rwin.getMouse()
        if 200<clickPoint.getX()<400 and 250<clickPoint.getY()<450: 
            if zarasize.getText() != "":
                insize = zarasize.getText()
                inchest = float(zara.getChestMeasurement(insize))
                inwaist = float(zara.getWaistMeasurement(insize))
                inhip = float(zara.getHipMeasurement(insize))
                Sizes(hnm,asos, zara, oldnavy, inchest, inwaist, inhip)
                choice = False
            elif asossize.getText() != "":
                insize = asossize.getText()
                inchest = float(asos.getChestMeasurement(insize))
                inwaist = float(asos.getWaistMeasurement(insize))
                inhip = float(asos.getHipMeasurement(insize))
                Sizes(hnm,asos, zara, oldnavy, inchest, inwaist, inhip)
                choice = False
        
    
    
def Home(hnm,asos, zara, oldnavy):
    #creates a home screen where users can choose to either enter their measurements and get their size,
    #or enter a size and get their other sizes
    win = GraphWin("Home", 900, 550)
    win.setBackground("Alice Blue")

    sizeBox = Rectangle(Point(200,10), Point(700,70))
    sizeBox.setFill("sky blue")
    sizeBox.draw(win)
    
    message = Text(Point(450,40), "Welcome to SI Sizing")
    message.setSize(30)
    message.setFace("courier") 
    message.draw(win)

    #creates prompts and entry points for users sizes
    chestmessage = Text(Point(280,100), "Enter your chest size in inches:")
    chest = Entry(Point(260,130), 5)
    chestmessage.draw(win)
    chest.draw(win)

    waistmessage = Text(Point(280,160), "Enter your waist size in inches:")
    waist = Entry(Point(260,190), 5)
    waistmessage.draw(win)
    waist.draw(win)

    hipmessage = Text(Point(280,220), "Enter your hip size in inches:")
    hip = Entry(Point(260,250), 5)
    hipmessage.draw(win)
    hip.draw(win)

    #creates options for users to either check their size or try and estimate it
    sizeBox = Rectangle(Point(20,330), Point(130,370))
    sizeBox.setFill("sky blue")
    sizeBox.draw(win)
    
    nextmessage = Text(Point(75,350), "Get Sizes")
    nextmessage.setFace('courier')
    nextmessage.setSize(15)
    nextmessage.draw(win)

    reverseBox = Rectangle(Point(150,330), Point(510,370))
    reverseBox.setFill("sky blue")
    reverseBox.draw(win)
    
    reversemessage = Text(Point(330,350), "Figure out your measurements")
    reversemessage.setFace('courier')
    reversemessage.setSize(15)
    reversemessage.draw(win)

    measure = Image(Point(700, 300), "measurement.gif")
    measure.draw(win)

    #checks to see if the user want to click on the basic gets size button, or takes annother size
    choice = True
    while choice:
        clickPoint = win.getMouse()
        if 20<clickPoint.getX()<130 and 330<clickPoint.getY()<370:
            inchest = float(chest.getText())
            inwaist = float(waist.getText())
            inhip = float(hip.getText())
            Sizes(hnm,asos, zara, oldnavy,inchest ,inwaist, inhip)
            choice = False
        elif 150<clickPoint.getX()<510 and 330<clickPoint.getY()<370:
            reverse(hnm,asos, zara, oldnavy)
            choice = False

def main():
    Home(hnm,asos, zara, oldnavy)
if __name__ == '__main__':
    main()
